#!C:/Users/sony/AppData/Local/Programs/Python/Python37/python.exe -u
print("Content-Type: text/html\n\n")
print()


import cgi,cgitb
cgitb.enable() #for debugging
form = cgi.FieldStorage()

Event_Type = form.getvalue('type')
Event_Date = form.getvalue('date')
#print("Name of the user is:",name)

import pymysql;
# Open connection to the database
db = pymysql.connect("localhost","root","Newjersey@18","vivanta by taj")

# Start a cursor object using cursor() method
cursor = db.cursor()

# Execute a SQL query using execute() method. This should return all the columns of heroes that use swords.
#x="INSERT INTO CUSTOMER (CUSTOMER_TYPE,CUSTOMER_NAME,CUSTOMER_AGE,ID_TYPE,ID_NUMBER,PAYMENT_MODE) VALUES (%s,%s,%s,%s,%s,%s)"
cursor.execute("INSERT INTO EVENT (Event_Type, Event_Date) VALUES (%s,%s)"
               ,(Event_Type, Event_Date))
db.commit()

# Fetch all the rows using fetchall() method.
data = cursor.fetchall()
print (data)

# disconnect from server
db.close()



