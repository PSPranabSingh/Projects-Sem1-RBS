CREATE TABLE `reservation` (
  `Reservation_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CustID` int(11) DEFAULT NULL,
  `EventID` int(11) DEFAULT NULL,
  `Floor_Number` int(11) DEFAULT NULL,
  `Room_Number` int(11) DEFAULT NULL,
  `Reservation_Type` varchar(1000) DEFAULT NULL,
  `Reservation_Start_Date` date DEFAULT NULL,
  `Reservation_End_Date` date DEFAULT NULL,
  `Room_Price` int(11) DEFAULT NULL,
  `Event_Price` int(11) DEFAULT NULL,
  PRIMARY KEY (`Reservation_ID`),
  KEY `CustID_idx` (`CustID`),
  KEY `EventID_idx` (`EventID`),
  KEY `Room_Number` (`Room_Number`,`Reservation_Start_Date`),
  CONSTRAINT `CustID` FOREIGN KEY (`CustID`) REFERENCES `customer` (`Customer_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `EventID` FOREIGN KEY (`EventID`) REFERENCES `event` (`Event_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1

insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('1', '1', '9', '902', 'Deluxe Room & Wedding Hall Rooftop Garden 10th Floor', '2017-12-08', '2017-12-10', '3000', '20000');
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('2', '1', '2', '210', 'Single Room', '2017-12-09', '2017-12-10', '500', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('3', '1', '2', '211', 'Single Room', '2017-12-09', '2017-12-10', '500', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('4', '1', '5', '508', 'Double Room', '2017-12-09', '2017-12-10', '900', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('5', '1', '2', '209', 'Single Room', '2017-12-09', '2017-12-10', '500', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('6', '1', '5', '509', 'Double Room', '2017-12-09', '2017-12-10', '900', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('7', null,'7', '702', 'Single Room', '2017-12-12', '2017-12-15', '2700', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('8', '2', '9', '901', 'Deluxe Room & Wedding Hall Rooftop Garden 10th Floor', '2017-12-17', '2017-12-19', '1500', '20000');
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('9', '2', '5', '505', 'Double Room', '2017-12-18', '2017-12-19', '900', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('10', '2', '5', '504', 'Double Room', '2017-12-18', '2017-12-19', '900', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('11', null,'7', '709', 'Single Room', '2017-12-21', '2017-12-23', '1800', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('12', null,'7', '703', 'Single Room', '2017-12-25', '2017-12-27', '1800', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('13', '1', '9', '904', 'Deluxe Room ', '2017-12-09', '2017-12-10', '1500', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('14', '4', '4', '407', 'Double Room & Dining Hall 3rd Floor', '2017-12-06', '2017-12-07', '900', '10000');
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('15', '4', '4', '408', 'Double Room', '2017-12-06', '2017-12-07', '900', Null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('16', '3', '8', '804', 'Single Room', '2017-12-02', '2017-12-03', '500', Null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('17', '4', '4', '406', 'Double Room', '2017-12-06', '2017-12-07', '900', Null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('18', '2', '9', '910', 'Deluxe Room', '2017-12-18', '2017-12-19', '900', null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('19', '4', '2', '202', 'Single Room', '2017-12-06', '2017-12-07', '500', Null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('20', '4', '2', '204', 'Single Room', '2017-12-06', '2017-12-07', '500', Null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('21', '4', '2', '205', 'Single Room', '2017-12-06', '2017-12-07', '500', Null);
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('22', '3', '7', '607', 'Double Room & Conference Hall 6th Floor', '2017-12-02', '2017-12-03', '900', '6000');
insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price)
values ('23', '3', '7', '608', 'Double Room', '2017-12-02', '2017-12-03', '900', Null);

select * from reservation;
