#!C:/Users/sony/AppData/Local/Programs/Python/Python37/python.exe -u
print("Content-Type: text/html\n\n")    
print()
import cgi,cgitb
cgitb.enable() #for debugging
form = cgi.FieldStorage()
cust_type = form.getvalue('type')
cust_name = form.getvalue('name')
cust_age = form.getvalue('age')
id_type = form.getvalue('idtype')
id_num = form.getvalue('idnum')
paymode = form.getvalue('paymode')
#print("Name of the user is:",name)

import pymysql;
# Open connection to the database
db = pymysql.connect("localhost","root","Newjersey@18","vivanta by taj")

# Start a cursor object using cursor() method
cursor = db.cursor()

# Execute a SQL query using execute() method. This should return all the columns of heroes that use swords.
#x="INSERT INTO CUSTOMER (CUSTOMER_TYPE,CUSTOMER_NAME,CUSTOMER_AGE,ID_TYPE,ID_NUMBER,PAYMENT_MODE) VALUES (%s,%s,%s,%s,%s,%s)"
cursor.execute("INSERT INTO CUSTOMER (CUSTOMER_TYPE,CUSTOMER_NAME,CUSTOMER_AGE,ID_TYPE,ID_NUMBER,PAYMENT_MODE) VALUES (%s,%s,%s,%s,%s,%s)"
               ,(cust_type,cust_name,cust_age,id_type,id_num,paymode))
db.commit()

# Fetch all the rows using fetchall() method.
data = cursor.fetchall()
print (data)

# disconnect from server
db.close()



