#!C:/Users/sony/AppData/Local/Programs/Python/Python37/python.exe -u
print("Content-Type: text/html\n\n")
print()
import cgi,cgitb
cgitb.enable() #for debugging
form = cgi.FieldStorage()
CustID = form.getvalue('id')
EventID = form.getvalue('eventid')
Floor_Number = form.getvalue('floornum')
Room_Number = form.getvalue('roomnum')
Reservation_Type = form.getvalue('type')
Reservation_Start_Date = form.getvalue('start')
Reservation_End_Date = form.getvalue('end')
Room_Price = form.getvalue('roomprice')
Event_Price = form.getvalue('eventprice')
#print("Name of the user is:",name)

import pymysql;
# Open connection to the database
db = pymysql.connect("localhost","root","Newjersey@18","vivanta by taj")

# Start a cursor object using cursor() method
cursor = db.cursor()

# Execute a SQL query using execute() method. This should return all the columns of heroes that use swords.
#x="INSERT INTO CUSTOMER (CUSTOMER_TYPE,CUSTOMER_NAME,CUSTOMER_AGE,ID_TYPE,ID_NUMBER,PAYMENT_MODE) VALUES (%s,%s,%s,%s,%s,%s)"
cursor.execute("insert into Reservation (CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"
               ,(CustID, EventID, Floor_Number, Room_Number, Reservation_Type, Reservation_Start_Date, Reservation_End_Date, Room_Price, Event_Price))
db.commit()

# Fetch all the rows using fetchall() method.
data = cursor.fetchall()
print (data)

# disconnect from server
db.close()



